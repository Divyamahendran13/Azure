// @flow

import { setDefaultEnv } from './env';

setDefaultEnv('production');
