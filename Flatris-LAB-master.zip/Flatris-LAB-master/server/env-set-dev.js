// @flow

import { setDefaultEnv } from './env';

setDefaultEnv('development');
