// @flow

import React from 'react';
import ZeroSum from '.';

export default <ZeroSum onNext={() => console.log('Next')} />;
