// @flow

import React from 'react';
import Multiplayer from '.';

export default <Multiplayer onNext={() => console.log('Next')} />;
