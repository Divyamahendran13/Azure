// @flow

import React from 'react';
import Left from './Left';

export default <Left onPress={() => console.log('Pressing...')} />;
