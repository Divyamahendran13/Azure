// @flow

import React from 'react';
import Right from './Right';

export default <Right onPress={() => console.log('Pressing...')} />;
