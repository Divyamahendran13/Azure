// @flow

import React from 'react';
import Rotate from './Rotate';

export default <Rotate onPress={() => console.log('Pressing...')} />;
